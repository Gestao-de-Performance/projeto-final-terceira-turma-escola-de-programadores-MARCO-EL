// script.js

// Função para adicionar evento de clique aos botões de navegação
document.addEventListener("DOMContentLoaded", function () {
  const navLinks = document.querySelectorAll("nav a");
  navLinks.forEach(function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      const targetId = link.getAttribute("href").substring(1);
      const targetSection = document.getElementById(targetId);
      targetSection.scrollIntoView({ behavior: "smooth" });
    });
  });
});

// Função para adicionar efeitos de transição às seções
document.addEventListener("scroll", function () {
  const sections = document.querySelectorAll("section");
  sections.forEach(function (section) {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.offsetHeight;
    const windowHeight = window.innerHeight;
    const scrollPosition = window.scrollY;

    if (
      scrollPosition >= sectionTop - windowHeight / 2 &&
      scrollPosition < sectionTop + sectionHeight - windowHeight / 2
    ) {
      section.classList.add("active");
    } else {
      section.classList.remove("active");
    }
  });
});
// Seleciona os botões
const entrarButton = document.getElementById("entrar");
const sairButton = document.getElementById("sair");

// Adiciona uma função ao botão "Entrar"
entrarButton.addEventListener("click", () => {
  alert('Você clicou no botão "Entrar"!');
  // Aqui você pode adicionar a lógica para autenticar o usuário, por exemplo
});

// Adiciona uma função ao botão "Sair"
sairButton.addEventListener("click", () => {
  alert('Você clicou no botão "Sair"!');
  // Aqui você pode adicionar a lógica para deslogar o usuário, por exemplo
});
